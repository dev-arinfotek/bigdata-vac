# Component installation

The master installer starts the complete stack. Individual installers start each service separately.

Dependency behavior:
- HDFS, PostgreSQL, Kafka, NiFi, Flink and MongoDB can be started independently.
- Debezium requires Kafka and PostgreSQL for its CDC exercise.
- Trino is configured with PostgreSQL and MongoDB catalogs.
- Streamlit uses the analytics services.
- Airflow is independent and contains a starter DAG.

Individual scripts intentionally do not hide dependencies. This allows instructors to demonstrate and troubleshoot each ecosystem separately.
