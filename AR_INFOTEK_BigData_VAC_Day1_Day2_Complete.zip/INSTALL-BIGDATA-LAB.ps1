$ErrorActionPreference="Stop"
Set-Location "$PSScriptRoot"
Write-Host "=== AR INFOTEK COMPLETE LAB INSTALLER ===" -ForegroundColor Cyan
if(Get-Command wsl.exe -EA SilentlyContinue){wsl.exe --update;wsl.exe --set-default-version 2}
if(-not (Get-Command docker.exe -EA SilentlyContinue)){
 winget install --id Docker.DockerDesktop --exact --accept-package-agreements --accept-source-agreements
 Write-Host "Start Docker Desktop and rerun this installer.";exit 0
}
docker version
docker compose version
& "$PSScriptRoot\scripts\INSTALL-DAY1.ps1"
Write-Host "`nDay 1 is ready. For Day 2 run .\scripts\INSTALL-DAY2.ps1" -ForegroundColor Green
