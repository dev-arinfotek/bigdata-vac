Set-Location "$PSScriptRoot\.."; docker compose down -v --remove-orphans; Write-Host "Lab reset complete."
