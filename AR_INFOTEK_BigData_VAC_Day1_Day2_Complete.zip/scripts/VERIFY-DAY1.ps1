Set-Location "$PSScriptRoot\.."
Write-Host "=== DAY 1 VERIFICATION ===" -ForegroundColor Cyan
docker compose ps
docker exec hdfs-namenode hdfs dfsadmin -report
docker exec hdfs-namenode hdfs dfs -ls -R /ecommerce
docker exec ecommerce-postgres pg_isready -U ecommerce -d ecommerce
docker exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka:29092 --list
Write-Host "Debezium: http://localhost:8083"
Write-Host "NiFi: https://localhost:8443/nifi"
Write-Host "Flink: http://localhost:8081"
