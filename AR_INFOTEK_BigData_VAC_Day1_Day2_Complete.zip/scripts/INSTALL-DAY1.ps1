$ErrorActionPreference="Stop"
Set-Location "$PSScriptRoot\.."
Write-Host "=== DAY 1: DISTRIBUTED DATA FOUNDATION + STREAMING ===" -ForegroundColor Cyan
docker compose up -d namenode datanode1 datanode2 datanode3 postgres kafka debezium nifi flink-jobmanager flink-taskmanager
& "$PSScriptRoot\INIT-DAY1.ps1"
& "$PSScriptRoot\VERIFY-DAY1.ps1"
