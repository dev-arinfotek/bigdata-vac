CREATE TABLE IF NOT EXISTS customers(customer_id VARCHAR(20) PRIMARY KEY,name VARCHAR(100),city VARCHAR(100));
CREATE TABLE IF NOT EXISTS products(product_id VARCHAR(20) PRIMARY KEY,product_name VARCHAR(100),category VARCHAR(100),price NUMERIC(12,2));
CREATE TABLE IF NOT EXISTS orders(order_id VARCHAR(20) PRIMARY KEY,customer_id VARCHAR(20),product_id VARCHAR(20),quantity INT,amount NUMERIC(12,2),status VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO customers VALUES ('C001','Arun','Chennai'),('C002','Priya','Bangalore'),('C003','Rahul','Hyderabad') ON CONFLICT DO NOTHING;
INSERT INTO products VALUES ('P001','Laptop','Electronics',65000),('P002','Smartphone','Electronics',30000),('P003','Headphones','Accessories',2500) ON CONFLICT DO NOTHING;
