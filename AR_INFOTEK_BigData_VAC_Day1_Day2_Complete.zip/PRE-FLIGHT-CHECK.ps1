$ErrorActionPreference="Continue"
$Pass=0;$Warn=0;$Fail=0
function P($n,$m){$script:Pass++;Write-Host "[PASS] $n : $m" -ForegroundColor Green}
function W($n,$m){$script:Warn++;Write-Host "[WARN] $n : $m" -ForegroundColor Yellow}
function F($n,$m){$script:Fail++;Write-Host "[FAIL] $n : $m" -ForegroundColor Red}
function S($x){Write-Host "`n--- $x ---" -ForegroundColor Cyan}
Write-Host "`n=== AR INFOTEK BIG DATA LAB PRE-FLIGHT ===" -ForegroundColor Cyan

S "SYSTEM"
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if($admin){P "Administrator" "Elevated"}else{F "Administrator" "Run as Administrator"}
$os=Get-CimInstance Win32_OperatingSystem;$build=[int]$os.BuildNumber
if($build -ge 19041){P "Windows" "$($os.Caption), build $build"}else{F "Windows" "Build 19041+"}
if([Environment]::Is64BitOperatingSystem){P "Architecture" "64-bit"}else{F "Architecture" "64-bit required"}
$cpu=Get-CimInstance Win32_Processor;$cores=($cpu|Measure-Object NumberOfLogicalProcessors -Sum).Sum
if($cores -ge 4){P "CPU" "$cores logical processors"}elseif($cores -ge 2){W "CPU" "$cores; 4+ recommended"}else{F "CPU" "$cores; insufficient"}
$ram=[math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,1)
if($ram -ge 32){P "RAM" "$ram GB"}elseif($ram -ge 16){W "RAM" "$ram GB; Day 1/Day 2 staged mode"}elseif($ram -ge 8){W "RAM" "$ram GB; selected services only"}else{F "RAM" "$ram GB"}
$c=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'";$free=[math]::Round($c.FreeSpace/1GB,1)
if($free -ge 80){P "Disk" "$free GB free"}elseif($free -ge 50){W "Disk" "$free GB; 80+ preferred"}else{F "Disk" "$free GB free"}
$virt=(Get-CimInstance Win32_Processor|Where-Object {$_.VirtualizationFirmwareEnabled}).Count -gt 0
if($virt){P "Virtualization" "Enabled"}else{W "Virtualization" "Not confirmed"}

S "WINDOWS / WSL"
$wsl=Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux
$vmp=Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform
if($wsl.State -eq "Enabled"){P "WSL feature" "Enabled"}else{F "WSL feature" "Disabled"}
if($vmp.State -eq "Enabled"){P "Virtual Machine Platform" "Enabled"}else{F "Virtual Machine Platform" "Disabled"}
if(Get-Command wsl.exe -EA SilentlyContinue){P "wsl.exe" "Available"; wsl --status; wsl --list --verbose}else{F "wsl.exe" "Missing"}

S "DOCKER"
if(Get-Command docker.exe -EA SilentlyContinue){
 P "Docker CLI" "Available"
 docker compose version
 if($LASTEXITCODE -eq 0){P "Compose" "v2 available"}else{F "Compose" "Unavailable"}
 docker info *> $null
 if($LASTEXITCODE -eq 0){
  P "Engine" "Running"
  try{
   $i=docker info --format '{{json .}}'|ConvertFrom-Json
   $dm=[math]::Round($i.MemTotal/1GB,1);$dc=$i.NCPU
   Write-Host "Docker resources: $dm GB RAM, $dc CPUs"
   if($dm -ge 12){P "Docker memory" "$dm GB"}elseif($dm -ge 8){W "Docker memory" "$dm GB; staged mode"}else{W "Docker memory" "$dm GB; limited"}
  }catch{W "Docker resources" "Could not read"}
 }else{W "Engine" "Not running"}
}else{W "Docker CLI" "Not installed"}

S "PORTS"
$ports=@{9870="HDFS UI";8020="HDFS RPC";9864="DataNode1";9865="DataNode2";9866="DataNode3";5432="PostgreSQL";9092="Kafka";8083="Debezium";8443="NiFi";8081="Flink";27017="MongoDB";8080="Trino";8501="Streamlit";8085="Airflow"}
foreach($kv in $ports.GetEnumerator()){if(Get-NetTCPConnection -LocalPort $kv.Key -State Listen -EA SilentlyContinue){W "Port $($kv.Key)" "$($kv.Value) already in use"}else{P "Port $($kv.Key)" "Available"}}

S "INSTALLER TOOLS"
if(Get-Command winget.exe -EA SilentlyContinue){P "Winget" "Available"}else{W "Winget" "Not available"}

S "RESOURCE PLAN"
if($ram -ge 32){P "Day 1/Day 2 plan" "Complete staged plan supported"}elseif($ram -ge 16){P "Day 1/Day 2 plan" "Recommended operating mode"}else{W "Day 1/Day 2 plan" "Use only selected services"}

Write-Host "`nSUMMARY: PASS=$Pass WARN=$Warn FAIL=$Fail"
if($Fail -eq 0){Write-Host "READY: review WARN items, then run Day 1 installer." -ForegroundColor Green}else{Write-Host "NOT READY: fix FAIL items first." -ForegroundColor Red}
